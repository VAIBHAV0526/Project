import numpy as np

# Constants
POPULATION_SIZE = 50
SWITCH_PROBABILITY = 0.8
MAX_GENERATIONS = 50
FEATURE_LENGTH = 21

def cost_function(actual_ratings, predicted_ratings):
    """Cost function to optimize using flower pollination method."""
    ms = sum(abs(np.array(predicted_ratings) - np.array(actual_ratings)))
    return ms / len(actual_ratings)

def flower_pollination_optimize(actual_ratings, predicted_ratings):
   
    """Get feature weights using flower pollination method."""

    # Generate initial population
    population = np.random.randint(2, size=(POPULATION_SIZE, FEATURE_LENGTH))
    fitness_vector = np.zeros(POPULATION_SIZE)

    for _ in range(MAX_GENERATIONS):
        print(cost_function(actual_ratings, predicted_ratings))
        for i in range(POPULATION_SIZE):
            if np.random.random() < SWITCH_PROBABILITY:
                # Global pollination
                k, j = np.random.choice(range(POPULATION_SIZE), 2, replace=False)
                new_solution = population[i] + np.random.normal() * (population[k] - population[j])
            else:
                # Local pollination
                new_solution = population[i] + np.random.normal() * (population[i] - np.mean(population, axis=0))

            # Apply bounds
            new_solution = np.clip(new_solution, 0, 1)

            # Evaluate new solution
            new_fitness = cost_function(actual_ratings, predicted_ratings)

            # If the new solution is better, update the solution
            if new_fitness < fitness_vector[i]:
                population[i] = new_solution
                fitness_vector[i] = new_fitness

    # Return the best solution
    best_solution = population[np.argmin(fitness_vector)]
    return best_solution
