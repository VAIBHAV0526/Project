import numpy as np

# Constants
INITIAL_POPULATION=50
MUTATION_RATE=0.05
NUM_OF_GENERATIONS=50
FEATURE_LENGTH=21
WINNER_PER_GEN=5
import numpy as np
from scipy.stats import levy

def levy_flight(size=1):
  """Generate a Lévy flight."""
  return levy.rvs(size=size)

# Example usage:

levy_flight(10)

def cost_function(actual_ratings, predicted_ratings):
    """Cost function to optimize using genetic method."""
    ms = sum(abs(np.array(predicted_ratings) - np.array(actual_ratings)))
    return ms / len(actual_ratings)

def crossover(solution1, solution2):
  """Crossover two solutions to generate a new solution.

  Args:
    solution1: A solution array.
    solution2: A solution array.

  Returns:
    A new solution array.
  """

  if solution2.ndim == 1:
    solution2 = np.expand_dims(solution2, axis=0)

  new_solution = np.zeros(solution1.shape)
  for i in range(solution2.shape[0]):
    if np.random.random() < 0.5:
      new_solution[i] = solution1[i]
    else:
      new_solution[i] = solution2[i]

  return new_solution

def flower_pollination_algorithm(actual_ratings, predicted_ratings):
  """Flower pollination algorithm for feature optimization."""

  # Initialization
  population = np.random.randint(2, size=(INITIAL_POPULATION, FEATURE_LENGTH))

  # Global pollination
  for i in range(population.shape[0]):
    new_solution = population[i] + levy_flight(size=FEATURE_LENGTH)
    population[i] = new_solution

  # Local pollination
  for i in range(population.shape[0]):
    neighbor = np.random.choice(population.flatten(), size=1)
    new_solution = crossover(population[i], neighbor)
    population[i] = new_solution

  # Selection
  fitness = np.array([cost_function(actual_ratings, predicted_ratings)])
  next_generation = population[np.argsort(fitness)[:WINNER_PER_GEN]]

  return next_generation