import numpy as np

# Constants
INITIAL_POPULATION=50
SWITCH_PROBABILITY=0.3
NUM_OF_GENERATIONS=50
FEATURE_LENGTH=21
NUM_OF_POLLINATORS=5  # Number of pollinators to use for each pollination

def cost_function(actual_ratings, predicted_ratings):
    """Cost function to optimize using FPA."""
    ms = sum(abs(np.array(predicted_ratings) - np.array(actual_ratings)))
    return ms / len(actual_ratings)


def flower_pollination_optimize(actual_ratings, predicted_ratings):
    """Get flower pollination feature weights."""

    # Generate initial population of pollinators
    pollinators = np.random.rand(INITIAL_POPULATION, FEATURE_LENGTH)
    best_pollinator = pollinators[0]  # Initialize the best solution with the first pollinator

    for generation in range(NUM_OF_GENERATIONS):

        for i in range(INITIAL_POPULATION):

            if np.random.rand() < SWITCH_PROBABILITY:  # Global pollination
                pollinator_index = np.random.randint(INITIAL_POPULATION)
                while pollinator_index == i:  # Ensure different pollinator is selected
                    pollinator_index = np.random.randint(INITIAL_POPULATION)

                pollinator_to_pollinate = pollinators[pollinator_index]

                # Levy flight
                levy_step = 1 / np.sqrt(FEATURE_LENGTH) * np.random.normal(0, 1, FEATURE_LENGTH)

                new_pollinator = pollinator_to_pollinate + levy_step

                # Update pollinator with better fitness
                if cost_function(actual_ratings, predicted_ratings) < cost_function(actual_ratings, predicted_ratings):
                    pollinators[i] = new_pollinator

            else:  # Local pollination
                # Select two pollinators from the same species (local neighborhood)
                pollinator_indices = np.random.choice(INITIAL_POPULATION, 2, replace=False)
                while pollinator_indices[0] == pollinator_indices[1]:
                    pollinator_indices = np.random.choice(INITIAL_POPULATION, 2, replace=False)

                pollinator1 = pollinators[pollinator_indices[0]]
                pollinator2 = pollinators[pollinator_indices[1]]

                # Pollinator mixing
                mixing_factor = np.random.rand()
                new_pollinator = mixing_factor * pollinator1 + (1 - mixing_factor) * pollinator2

                # Update pollinator with better fitness
                if cost_function(actual_ratings, predicted_ratings) < cost_function(actual_ratings, predicted_ratings):
                    pollinators[i] = new_pollinator

            # Update the best pollinator
            best_fitness = cost_function(actual_ratings, predicted_ratings)
            if best_fitness < cost_function(actual_ratings, predicted_ratings):
                best_pollinator = pollinators[i]

    return best_pollinator

