"""Settings file for the project."""

# Constants
NO_OF_FEATURES = 21
NO_OF_GENRES = 19